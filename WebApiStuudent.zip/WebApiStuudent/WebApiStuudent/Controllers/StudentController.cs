using Microsoft.AspNetCore.Mvc;
using WebApiStuudent.Interface;
using WebApiStuudent.Models;

namespace WebApiStuudent.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class StudentController : ControllerBase
    {
       
        private readonly ILogger<StudentController> _logger;
        private readonly IStudentRepo _studentRepo;

        public StudentController(ILogger<StudentController> logger, IStudentRepo studentRepo)
        {
            _logger = logger;
            _studentRepo = studentRepo;
        }

        [HttpGet]
        public IEnumerable<StudentMast> GetStudents()
        {
            var student = _studentRepo.GetStudents();
            return student;
        }

        [HttpGet]
        [Route("students")]
        public IEnumerable<StudentDetailDto> GetAllStudents()
        {
            var student = _studentRepo.GetAllStudents();
            return student;
        }
    }
}