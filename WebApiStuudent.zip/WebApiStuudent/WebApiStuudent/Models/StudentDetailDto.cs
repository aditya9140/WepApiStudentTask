﻿namespace WebApiStuudent.Models
{
    public class StudentDetailDto
    {
        public int? StdId { get; set; }
        public string? Name { get; set; }
        public int? AcdYear { get; set; }
        public string? Standard { get; set; }
        public int StdDetId { get; set; }
        public string? AcdTerm { get; set; }
        public string? Subject { get; set; }
        public decimal? AvgMarks { get; set; }
        public decimal? Marks { get; set; }
        public decimal? MarksOutOf { get; set; }

    }
}
