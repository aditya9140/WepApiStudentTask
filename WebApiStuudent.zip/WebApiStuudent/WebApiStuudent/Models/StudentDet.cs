﻿using System;
using System.Collections.Generic;

namespace WebApiStuudent.Models
{
    public partial class StudentDet
    {
        public int StdDetId { get; set; }
        public int? StdId { get; set; }
        public string? AcdTerm { get; set; }
        public string? Subject { get; set; }
        public decimal? Marks { get; set; }
        public decimal? MarksOutOf { get; set; }
    }
}
