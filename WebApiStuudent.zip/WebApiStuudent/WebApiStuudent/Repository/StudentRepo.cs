﻿using WebApiStuudent.Interface;
using WebApiStuudent.Models;

namespace WebApiStuudent.Repository
{
    public class StudentRepo : IStudentRepo
    {
        public IEnumerable<StudentDetailDto> GetAllStudents()
        {
            var context = new DBStudentContext();
            var studentDetails = from stu in context.StudentMasts
                                     join studentDet in context.StudentDets on stu.StdId equals studentDet.StdId
                                     where stu.StdId == studentDet.StdId
                                     select new StudentDetailDto
                                     {
                                         Name = stu.Name,
                                         AcdYear = stu.AcdYear,
                                         Standard = stu.Standard,
                                         Subject = studentDet.Subject,
                                         AvgMarks = studentDet.Marks + studentDet.Marks + studentDet.Marks / 3,
                                         Marks = studentDet.Marks,
                                         MarksOutOf = studentDet.MarksOutOf,
                                     };
                return studentDetails.Select(x => new StudentDetailDto
                {
                    Name = x.Name,
                    AcdTerm = x.AcdTerm,
                    Standard = x.Standard,
                    Subject = x.Subject,
                    AvgMarks = x.AvgMarks,
                    Marks = x.Marks,
                    MarksOutOf = x.MarksOutOf,
                });
        }

        public IEnumerable<StudentMast> GetStudents()
        {
            using (var context = new DBStudentContext())
            {
                return context.StudentMasts.ToList();
            }
        }
    }
}
