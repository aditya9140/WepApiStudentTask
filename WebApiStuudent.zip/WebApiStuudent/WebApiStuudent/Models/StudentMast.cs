﻿using System;
using System.Collections.Generic;

namespace WebApiStuudent.Models
{
    public partial class StudentMast
    {
        public int StdId { get; set; }
        public string? Name { get; set; }
        public int? AcdYear { get; set; }
        public string? Standard { get; set; }
    }
}
