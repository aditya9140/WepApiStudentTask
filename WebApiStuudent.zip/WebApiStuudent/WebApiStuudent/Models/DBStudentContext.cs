﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace WebApiStuudent.Models
{
    public partial class DBStudentContext : DbContext
    {
        public DBStudentContext()
        {
        }

        public DBStudentContext(DbContextOptions<DBStudentContext> options)
            : base(options)
        {
        }

        public virtual DbSet<StudentDet> StudentDets { get; set; } = null!;
        public virtual DbSet<StudentMast> StudentMasts { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
               // #warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Server=DESKTOP-B2HJ4PO\\SQLEXPRESS; Database=DBStudent;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<StudentDet>(entity =>
            {
                entity.HasKey(e => e.StdDetId);

                entity.ToTable("studentDet");

                entity.Property(e => e.StdDetId).HasColumnName("STD_det_id");

                entity.Property(e => e.AcdTerm)
                    .HasMaxLength(100)
                    .HasColumnName("ACD_Term")
                    .IsFixedLength();

                entity.Property(e => e.Marks).HasColumnType("decimal(18, 0)");

                entity.Property(e => e.MarksOutOf)
                    .HasColumnType("decimal(18, 0)")
                    .HasDefaultValueSql("((50))");

                entity.Property(e => e.StdId).HasColumnName("STD_ID");

                entity.Property(e => e.Subject)
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<StudentMast>(entity =>
            {
                entity.HasKey(e => e.StdId);

                entity.ToTable("studentMast");

                entity.Property(e => e.StdId).HasColumnName("STD_ID");

                entity.Property(e => e.AcdYear).HasColumnName("ACD_Year");

                entity.Property(e => e.Name)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Standard)
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
