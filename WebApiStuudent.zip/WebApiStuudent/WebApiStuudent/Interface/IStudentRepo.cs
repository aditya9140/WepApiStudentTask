﻿using WebApiStuudent.Models;

namespace WebApiStuudent.Interface
{
    public interface IStudentRepo
    {
        IEnumerable<StudentMast> GetStudents();

        IEnumerable<StudentDetailDto> GetAllStudents();
    }
}
